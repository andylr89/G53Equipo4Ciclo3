package com.grupo53.tienda53;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tienda53Application {

	public static void main(String[] args) {
		SpringApplication.run(Tienda53Application.class, args);
	}

}
