package com.grupo53.tienda53;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tienda53ApplicationTests {

	@Test
	void contextLoads() {
	}

}
